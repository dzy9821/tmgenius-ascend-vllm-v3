"""RNNoise: Noise suppression deep learning library."""

from .rnnoise import RNNoise, init_weights
